# FreeCAD init script of the Cfd module
# (c) 2001 Juergen Riegel LGPL
